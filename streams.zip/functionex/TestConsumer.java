package com.functionex;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class TestConsumer {
	

	public static void main(String[] args) {
		
     Consumer<Integer> consumer=i -> System.out.println(" "+i*i);
     Consumer<Integer>comsumerwithAndthen=i -> System.out.print("(Square of number="+i+")");
     Consumer<Integer> con=	 comsumerwithAndthen.andThen(consumer);
     
     List<Integer> listarr=Arrays.asList(new Integer(10),
    		 new Integer(45),
    		 new Integer(67),
    		 new Integer(37));
     
     printConsumer(listarr, con);
	}
	
	public static void printConsumer(List<Integer> listofInt,Consumer<Integer> consumer)
	{
		for(Integer integer: listofInt)
		{
			consumer.accept(integer);
		}
	}

}
