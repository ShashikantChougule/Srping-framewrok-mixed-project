package com.functionex;

import java.util.Date;
import java.util.function.Supplier;

public class SupplierEx {

	public static void main(String[] args) {
    Supplier<Date> date=()->new Date();
    System.out.println(date.get());
    
   Supplier<String> randomString=() ->{
	   String arr[]= {"Red","Yellow","Green","Pink"};
	   int x= (int)(Math.random()*4);
	   return arr[x];
   };
   System.out.println(randomString.get());
    
    
	}

}
