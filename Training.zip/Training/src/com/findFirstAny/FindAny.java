package com.findFirstAny;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class FindAny {

	public static void main(String[] args) {
		
		
		 List<Integer> list = Arrays.asList(2, 4, 6, 8, 10);
		  
	      
	        Optional<Integer> answer = list.stream().findAny();
	  
	        
	        if (answer.isPresent()) {
	            System.out.println(answer.get());
	        }
	        else {
	            System.out.println("no value");
	        }
	        
	        
	        
	        Optional<Integer> answer1 = list.stream().findFirst();
	        
	        
	        if (answer.isPresent()) {
	            System.out.println(answer1.get());
	        }
	        else {
	            System.out.println("no value");
	        }
		
	}

}
