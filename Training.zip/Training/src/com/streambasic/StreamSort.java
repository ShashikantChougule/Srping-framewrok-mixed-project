package com.streambasic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class StreamSort {

	public static void main(String[] args) {
		
		
		List<Employee> list = new ArrayList<>(Arrays.asList(
		        new Employee("Shashi", 25000),
		        new Employee("Akash", 26000), new Employee("Vishal", 27000), new Employee("Prithvi", 28000)));
		
		List<Employee> sortedList = list.stream()
		                                .sorted(Comparator.comparing(Employee::getName))
		                                .collect(Collectors.toList());
		
		List<Employee> sortedList1 = list.stream()
                .sorted(Comparator.comparing(Employee::getSalary))
                .collect(Collectors.toList());
		
		sortedList.forEach(System.out::println);
		System.out.println("-------------------------------------------------");
		sortedList1.forEach(System.out::println);       
	    
	}

}
