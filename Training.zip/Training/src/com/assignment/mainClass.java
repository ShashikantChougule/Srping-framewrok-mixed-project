package com.assignment;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class mainClass {
	
	public static void getCustomerdata() {}






	public static void main(String[] args) {
		List<Customer> custData = new ArrayList<Customer>();

		List<String> phoneNumcust1= new ArrayList<>();
		phoneNumcust1.add("123456789");
		phoneNumcust1.add("987654321");
		phoneNumcust1.add("786543219");

		List<String> phoneNumcust2 = new ArrayList<>();
		phoneNumcust2.add("987654321");
		phoneNumcust2.add("678954321");
		phoneNumcust2.add("11223344555");
		
		
		
		
		custData.add(new Customer(101, "Shashi", phoneNumcust1));
		custData.add(new Customer(102, "Akash", phoneNumcust2));
		
		
		;
		
		List<String> outputList=custData.stream()
				                        .flatMap(cust->cust.getPhonenumber().stream())
				                        .collect(Collectors.toList());
		System.out.println(outputList);
		
		//List<String> studentList = empData.stream().map(stud -> stud.getFirstName()).collect(Collectors.toList());
		//System.out.println(studentList);
		
		List<String> customerList=custData.stream()
				                          .map(cust->cust.getName())
				                          .collect(Collectors.toList());
		System.out.println(customerList);
		
		
		
		
		
		
        
        
        
		
        
		

	}

}
