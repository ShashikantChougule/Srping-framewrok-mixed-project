package com.training;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ColorExample {

	public static void main(String[] args) {
		
		  List<String> list=Arrays.asList("RED","BLUE","BLACK","GREEN","BROWN");
			/*
			 * List<String> filteredList=new ArrayList<>();
			 * 
			 * 
			 * for(String entry:list) { if(entry.startsWith("B")) { filteredList.add(entry);
			 * } }
			 * 
			 * 
			 * System.out.println(filteredList);
			 */
			  
			  
			  String filteredList=list.stream()
					                  .filter(entry->entry.startsWith("B"))
					                  .collect(Collectors.joining(",","[","]"));
			  
			  System.out.println(filteredList);
			 

	}

}
