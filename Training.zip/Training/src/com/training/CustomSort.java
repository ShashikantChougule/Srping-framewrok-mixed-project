package com.training;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

public class CustomSort {

	public static void main(String[] args) {
		
		Employee e1 = new Employee(101, "Shashi", 25);
        Employee e2 = new Employee(102, "Akash", 26);
        
        List<Employee> list = new ArrayList<Employee>();
        list.add(e1);
        list.add(e2);
        
        
		/*
		 * TreeSet<Employee> TS= new TreeSet<>(); TS.add(e1); TS.add(e2);
		 */
       
      
		/*
		 * Comparator<Employee> compareByName = Comparator.comparing(e -> e.getName());
		 * Collections.sort(list, compareByName); System.out.println(list);
		 */
        
        
		/*
		 * Comparator<Employee> compareById = Comparator.comparing(e -> e.getId());
		 * Collections.sort(list, compareById); System.out.println(list);
		 */
        
        
        Comparator<Employee> compareByAge = Comparator.comparing(e -> e.getAge());
	    Collections.sort(list, compareByAge); System.out.println(list);
	    
	    
        
        
		
       
		  
		

	}

}
