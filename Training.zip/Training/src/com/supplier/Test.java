package com.supplier;

import java.util.function.Supplier;

public class Test {

	public static void main(String[] args) {
		Supplier<String> s = () -> {
			   String symbols = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			   Supplier<Integer> d = () -> (int)(Math.random() * 10);
			   Supplier<Character> c = () -> symbols.charAt((int)(Math.random() * 26));
			   String psw = "";
			   for(int i=0; i<8; i++) {
			    if(i%2 == 0) {
			     psw += c.get();
			    } else {
			     psw += d.get();
			    }
			   }
			   return psw;
			  };
			
			  System.out.println(s.get());

	}

}
