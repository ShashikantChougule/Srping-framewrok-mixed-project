package spring;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Customer {	
	
private int custId;
private String custName;   // premitive Injection

//email
//gender
//Passport passport

@Autowired
@Qualifier("add2")
private Address address;    // Object inject

@Autowired
private List<PhoneNumbers> phno;  // Collection injection

public Customer() {
	System.out.println("object created");
}


public Customer(int custId, String custName, Address address) {
	
	this.custId = custId;
	this.custName = custName;
	this.address = address;
}

/*
 * public Customer(int custId, String custName, Address address,
 * List<PhoneNumbers> phno) { super(); this.custId = custId; this.custName =
 * custName; this.address = address; this.phno = phno; }
 */


public List<PhoneNumbers> getPhno() {
	return phno;
}

public void setPhno(List<PhoneNumbers> phno) {
	this.phno = phno;
}

public Address getAddress() {
	return address;
}



public void setAddress(Address address) {
	this.address = address;
}



public int getCustId() {
	return custId;
}
public void setCustId(int custId) {
	this.custId = custId;
}
public String getCustName() {
	return custName;
}
public void setCustName(String custName) {
	this.custName = custName;
}

@Override
public String toString() {
	return "Customer [custId=" + custId + ", custName=" + custName + ", address=" + address + ", phno=" + phno + "]";
}





}
