package spring;

public class PhoneNumbers {
 private int phno;

public PhoneNumbers() {
	super();
}

public PhoneNumbers(int phno) {
	super();
	this.phno = phno;
}

public int getPhno() {
	return phno;
}

public void setPhno(int phno) {
	this.phno = phno;
}

@Override
public String toString() {
	return "PhoneNumbers [phno=" + phno + "]";
}
 
}
