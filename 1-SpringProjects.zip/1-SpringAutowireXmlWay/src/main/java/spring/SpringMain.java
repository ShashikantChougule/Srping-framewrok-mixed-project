package spring;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class SpringMain {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("spring_ObjectDepency.xml");

		Customer customer = context.getBean("cust", Customer.class);

		System.out.println(customer);
		

		/*
		 * ClassPathXmlApplicationContext context2 = new
		 * ClassPathXmlApplicationContext("spring.xml");
		 * 
		 * Customer customer1 = context2.getBean("cust2", Customer.class);
		 * 
		 * System.out.println(customer1);
		 * 
		 * context2.close();
		 */

		/*
		 * BeanFactory factory=new XmlBeanFactory(new ClassPathResource("spring.xml"));
		 * Customer customer= factory.getBean("cust",Customer.class);
		 */
	}

}
