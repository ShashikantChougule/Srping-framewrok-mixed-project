package spring;

public interface InjectProperty {
	public void inject();

}
