package com.spring.mvc.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.spring.mvc.model.Product;
@Controller
@RequestMapping("/product")
public class ProductController {
	
	
	/* @ModelAttribute can be used either as a method parameter or at the method level.
	 * 
	 * method that adds an attribute named headerMessage to all models defined in the controller class.
	 * */
	
	@ModelAttribute
	public void addingCommonObject(Model model) {
	
		model.addAttribute("headerMessage","Vinsys IT Services (I) Pvt. Ltd ");
	}
	// /product/getData
	@RequestMapping(value="/getData", method=RequestMethod.GET)
	public ModelAndView getProductData() {
		
		System.out.println("Using the controller to GetEmployeeData");
		ModelAndView model = new ModelAndView("GetProductData");
		
		return model;
	}
	// /product/registerProduct
	@RequestMapping(value="/registerProduct",method=RequestMethod.POST)
	public ModelAndView submitProductData(@ModelAttribute("product") Product productDetails) {
						
		System.out.println("Using the Model Attribute to display the data");
		
		ModelAndView model = new ModelAndView("ProductDetails");
		
		return model;
		
		
		
		
	}


}
