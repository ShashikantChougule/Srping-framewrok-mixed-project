package com.spring.mvc.repository;

import java.util.List;

import com.spring.mvc.model.Product;


public interface ProductRepository {
	
	void addProduct(com.spring.mvc.model.Product product);
	void deleteProduct(int productId);
	void updateProduct(Product product);
	List<Product> getAllProducts();
	Product getProductById(int productId);
	

}
