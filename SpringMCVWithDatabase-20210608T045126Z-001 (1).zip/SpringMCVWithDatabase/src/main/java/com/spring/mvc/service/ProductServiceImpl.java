package com.spring.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.spring.mvc.model.Product;
import com.spring.mvc.repository.ProductRepository;


@Service("productService")
public class ProductServiceImpl implements ProductService {

   
	ProductRepository productrepository;
    
    public ProductServiceImpl() {
    	
    }
    @Autowired
    @Qualifier("productRepository")
    public void setProductrepository(ProductRepository productrepository) {
    	System.out.println("Product Repository Object assigned in Service");
		this.productrepository = productrepository;
	}
	public ProductRepository getProductrepository() {
		return productrepository;
	}
	
	public void addProduct(Product product) {
		productrepository.addProduct(product);
		
	}

	public void deleteProduct(int productId) {
		productrepository.deleteProduct(productId);
		
	}
	
	public void updateProduct(Product product) {
		productrepository.updateProduct(product);
		
	}
	
	public List<Product> getAllProducts() {
		return productrepository.getAllProducts();
	}

	public Product getProductById(int productId) {
		return productrepository.getProductById(productId);
	}

	

	

}
