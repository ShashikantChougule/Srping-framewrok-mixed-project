package com.spring.mvc.service;

import java.util.List;

import com.spring.mvc.model.Product;



public interface ProductService {
	
	void addProduct(Product product);
	void deleteProduct(int productId);
	void updateProduct(Product product);
	List<Product> getAllProducts();
	Product getProductById(int productId);
	

}
