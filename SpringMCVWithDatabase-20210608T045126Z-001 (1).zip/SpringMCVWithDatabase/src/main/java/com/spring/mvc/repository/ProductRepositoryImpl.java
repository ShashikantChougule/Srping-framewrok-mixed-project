package com.spring.mvc.repository;

import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.spring.mvc.model.Product;

import java.sql.ResultSet;

@Repository("productRepository")
public class ProductRepositoryImpl implements ProductRepository {

	
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	public ProductRepositoryImpl(DataSource dataSource) {
		System.out.println("Product Repository Object Created");
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		
     this.jdbcTemplate = jdbcTemplate;
		
	}

	
	public void addProduct(Product product) {
		String sql = "insert into product values(?,?,?,?)";
		Object productdetails[] = {new Integer(product.getProductId()),product.getProductName(),product.getProductType(),new Integer(product.getProductPrice())};
		jdbcTemplate.update(sql,productdetails );
		System.out.println("One product Inserted...");
	}


	public void deleteProduct(int productId) {
		String sql="delete from product  where  productId=?";
		int i=jdbcTemplate.update(sql,new Object[]{(productId)});
		System.out.println(""+i+" Records get deleted");
	}

	
	public void updateProduct(Product product) {
		
		String sql="update product set productName=?,productType=?,productPrice=? where  productId=?";
		int i=jdbcTemplate.update(sql,new Object[]{product.getProductName(),product.getProductType(),product.getProductPrice(),product.getProductId()});
		System.out.println(""+i+" Records get updated");
	}

	
	public List<Product> getAllProducts() {
		String sql="select * from product";
		List<Product> productList=jdbcTemplate.query(sql,new RowMapper<Product>() {

			
			public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
				System.out.println("Inside the maprow");
				// TODO Auto-generated method stub
				Product p=new Product();
				p.setProductId(rs.getInt("productId"));
				p.setProductName(rs.getString("productName"));
				p.setProductType(rs.getString(3));
				p.setProductPrice(rs.getInt(4));
				
				return p;
			}
			
		});
		return productList;
	}

	
	@SuppressWarnings("unchecked")
	public Product getProductById(int productId) {
		String sql ="select * from product where productId=?";

		Object setProductId[]= {new Integer(productId)};
		
		return (Product) jdbcTemplate.query(sql, setProductId,
				new ResultSetExtractor() 
		{
						
		
			public Object extractData(java.sql.ResultSet rs) throws SQLException, DataAccessException {
				if(rs.next())
				{
					Product product = new Product();
					product.setProductId(rs.getInt(1));
					product.setProductName(rs.getString(2));
					product.setProductType(rs.getString(3));
					product.setProductPrice(rs.getInt(4));
					
					return product;
				}
				else
					return null;
			}
		});
	}
	
  

}
