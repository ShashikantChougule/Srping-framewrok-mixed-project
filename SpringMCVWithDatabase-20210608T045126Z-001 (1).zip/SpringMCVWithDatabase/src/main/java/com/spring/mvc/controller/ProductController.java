package com.spring.mvc.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.spring.mvc.model.Product;
import com.spring.mvc.service.ProductService;

@Controller
@RequestMapping("/product")
public class ProductController {
	
	  
	   ProductService productService;
	   
	  @Autowired
	  @Qualifier("productService")
	 public void setProductService(ProductService productService) {
		  System.out.println("productService object is assigned for controller usage");
		this.productService = productService;
	 }
	  
	 @ModelAttribute
	  public void addingCommonObject(Model model) {
		
			model.addAttribute("headerMessage","Vinsys IT Services (I) Pvt. Ltd ");
		}
		
		@RequestMapping(value="/addProduct", method=RequestMethod.GET)
		public ModelAndView addProduct() {
			
			System.out.println("Using the controller to Add Product");
			ModelAndView model = new ModelAndView("AddProduct");
			
			return model;
		}
		
		@RequestMapping(value="/registerProduct",method=RequestMethod.POST)
		public ModelAndView submitProductData(@ModelAttribute("product") Product productDetails) {
							
			System.out.println("Using the Model Attribute to display the data");
			
			 this.productService.addProduct(productDetails);
		
			  ModelAndView model = new ModelAndView("home");
			
			return model;
							
		}
		@RequestMapping(value="/getAll",method=RequestMethod.GET)
		public ModelAndView getAllProductInfo() {

			
		System.out.println("Using the Model Attribute to display the data");
		
		List<Product> productList = this.productService.getAllProducts();
		 ModelAndView model = new ModelAndView("DisplayProduct");
		 
		 model.addObject("productList",productList);
         return  model;
			
		}
      
		@RequestMapping(value="/getProduct/{productId}")    
	    public ModelAndView getProduct(@PathVariable int productId){ 
			
			System.out.println("Going to the  editPage by "+productId);
	        Product p = this.productService.getProductById(productId); 
	        ModelAndView model = new ModelAndView("editProduct");
			 
			 model.addObject("product",p);
	         return  model;   
	          
	    } 
		
		@RequestMapping(value="/edit")    
	    public ModelAndView editProduct(@ModelAttribute("product") Product productDetails){ 
			
			System.out.println("Going to the product page by ");
	        this.productService.updateProduct(productDetails); 
	        ModelAndView model = new ModelAndView("home");
			 return model;
	          
	    }   
		
		

			
		

	
	
	

}
